# CppMinecraftLauncher
> This is a Minecraft Launcher by C++,Python and Java(Coming Soon™)

# How To build Launcher

    1. Getting our Launcher's src: 'gh repo clone zcygod1337/MinecraftLauncher'
    2. Finishing your Gradle's Build Tasks
    3. You Should Start Main.class
    4. Enjoying?

# First of all

You Should install Java(Version: 21) and install all kinds of C++ and Python Version

zcygod 正在重构 main.cpp,添加链接库支持（以后写的东西可以模块化）
