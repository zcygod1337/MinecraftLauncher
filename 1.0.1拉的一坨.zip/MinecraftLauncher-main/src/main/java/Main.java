import swing.SwingMain;

public class Main {
    public static void main(String[] args) {
        SwingMain.startSwing();
    }
}
